package com.example.apptorsion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ejercicio1 extends AppCompatActivity {
    Button siguiente;
    Button seleccionar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio1);

        siguiente =(Button)findViewById(R.id.btnSig);

        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent siguiente = new Intent(ejercicio1.this, ejercicio2.class);
                startActivity(siguiente);

            }
        });
        seleccionar =(Button)findViewById(R.id.btnSel);

        seleccionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent seleccionar = new Intent(ejercicio1.this, solucionEj.class);
                startActivity(seleccionar);

            }
        });

    }
}