package com.example.apptorsion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ejercicio4 extends AppCompatActivity {

    Button anterior;
    Button seleccionar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio4);

        anterior =(Button)findViewById(R.id.btnAnt3);

        anterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent anterior = new Intent(ejercicio4.this, ejercicio3.class);
                startActivity(anterior);

            }
        });

        seleccionar =(Button)findViewById(R.id.btnSel4);

        seleccionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent seleccionar = new Intent(ejercicio4.this, solucionEj4.class);
                startActivity(seleccionar);

            }
        });

    }
}