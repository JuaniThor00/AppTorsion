package com.example.apptorsion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ejercicio2 extends AppCompatActivity {

    Button siguiente;
    Button anterior;
    Button seleccionar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio2);

        siguiente =(Button)findViewById(R.id.btnSig2);

        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent siguiente = new Intent(ejercicio2.this, ejercicio3.class);
                startActivity(siguiente);

            }
        });

        anterior =(Button)findViewById(R.id.btnAnt);

        anterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent anterior = new Intent(ejercicio2.this, ejercicio1.class);
                startActivity(anterior);

            }
        });

        seleccionar =(Button)findViewById(R.id.btnSel2);

        seleccionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent seleccionar = new Intent(ejercicio2.this, solucionEj2.class);
                startActivity(seleccionar);

            }
        });

    }
}