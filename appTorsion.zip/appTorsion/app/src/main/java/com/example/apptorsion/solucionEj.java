package com.example.apptorsion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class solucionEj extends AppCompatActivity {

    Button atras;
    Button resolver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solucion_ej);


        atras = (Button) findViewById(R.id.btnAtr);

        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent atras = new Intent(solucionEj.this, MainActivity.class);
                startActivity(atras);

            }
        });
    }
}